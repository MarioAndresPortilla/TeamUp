import React from "react";
//renders a footer for every page
export class Footer extends React.Component {
render() {
    return (
        <footer>
        <span><a href="/">TeamUp</a> | <span class="far fa-copyright"></span> 2022 All rights reserved.</span>
        </footer>
    )
}
}